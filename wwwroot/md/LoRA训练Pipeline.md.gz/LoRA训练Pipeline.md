﻿#### Lora训练Pipeline

---

<dotnet>*dotnet8, ASP.NET Core, MongoDB, Kubernetes, Docker, 阿里云Oss, Azure DevOps CI/CD*</dotnet> 

---

目标: 为达人生成面容资产(LoRA)用于微调生图大模型, 生成达人面容的图片资源.

---

达人照片 -> 校验, 存储 -> 调度给训练服务 -> 管理中间状态 -> LoRA资产 -> 通知用户生成完成

-> 模板 + LoRA AIGC 一组用户视频电话形象 -> 发送给视频通话Pipeline


