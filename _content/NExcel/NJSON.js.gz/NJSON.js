export function stringify(obj) {
    return JSON.stringify(obj);
}
export function parse(str) {
    return JSON.parse(str);
}
