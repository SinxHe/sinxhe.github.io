export function GetFill(format) {
    return format.fill;
}
