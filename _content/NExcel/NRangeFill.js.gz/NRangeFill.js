export function GetColor(fill) {
    return fill.color;
}
export function SetColor(fill, color) {
    fill.color = color;
}
